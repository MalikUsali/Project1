-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2020 at 10:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `ap_id` int(10) NOT NULL,
  `ap_patient_name` varchar(50) NOT NULL,
  `ap_patient_contact` varchar(20) NOT NULL,
  `doctor_name` varchar(50) NOT NULL,
  `day` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`ap_id`, `ap_patient_name`, `ap_patient_contact`, `doctor_name`, `day`) VALUES
(1, 'danial', '02313433', 'Dr.Usama Ali', 'monday'),
(3, 'sami', '865312211', 'dr.usama', 'wednesday'),
(4, 'kalim', '0239876543', 'dr.usassedf', 'thursday'),
(5, 'hamza', '98716362727', 'Dr.Ustaad G', 'Friday'),
(6, 'samad', '765563433', 'dr.sami', 'saturday');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `d_id` int(20) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `age` int(10) NOT NULL,
  `shift` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`d_id`, `d_name`, `email`, `contact`, `age`, `shift`) VALUES
(1, 'newUser', 'aaa@gmail.com', '+9244438237', 23, 'day'),
(2, 'stan', 'stan@gmail.com', '+9234338237', 32, 'night'),
(3, 'steve', 'steve@gmail.com', '+923278287', 27, 'night'),
(4, 'User11', 'user@gmail.com', '+98765432123', 44, 'night'),
(5, 'DR.Hamza', 'Hamzailyas@123mail.c', '72647363772', 21, 'Night'),
(6, 'DR.Hamza', 'hmza@gmail.com', '73462773', 23, 'day'),
(7, 'dr.aliali', 'ali@mail.xom', '63827828272', 20, 'night'),
(8, 'malik', 'malik@mail.com', '728362828376', 73, 'day');

-- --------------------------------------------------------

--
-- Table structure for table `nurses`
--

CREATE TABLE `nurses` (
  `n_id` int(10) NOT NULL,
  `n_name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `age` int(10) NOT NULL,
  `shift` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nurses`
--

INSERT INTO `nurses` (`n_id`, `n_name`, `email`, `contact`, `age`, `shift`) VALUES
(1, 'samiii', 'oza@gmail.com', '+9278438237', 25, 'night'),
(2, 'samiii', 'oza@gmail.com', '+9278438237', 25, 'day'),
(3, 'aaqiaa', 'zola@gmail.com', '+927846543', 15, 'night'),
(6, 'new user3', 'geasas@gmail.com', '+92333223221', 21, 'day'),
(7, 'new user3', 'geasas@gmail.com', '+92333223221', 21, 'day'),
(8, 'new user3', 'geasas@gmail.com', '+92333223221', 21, 'day'),
(9, 'new user7', 'avfaa@gmail.com', '03333333333', 34, 'night'),
(10, 'new user8', 'avnbbb@gmail.com', '0388883333', 39, 'day'),
(11, 'aasi', 'dssaa23@gmail.com', '+9278438237', 56, 'day'),
(15, 'sister', 'ssst@gmail.com', '+9333224338237', 35, 'day'),
(16, 'raniiii', 'raniii3@gmail.com', '+92444388777', 22, 'night'),
(17, 'Nurse21', 'nurs@hmail.com', '637263827', 99, 'Night');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `p_id` int(10) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `age` int(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`p_id`, `p_name`, `email`, `contact`, `age`, `status`) VALUES
(1, 'ali', 'exae@gmail.com', '+92334338237', 20, 'indoor'),
(2, 'sami', 'usaaa@gmail.com', '+9209987433333', 23, 'outdoor'),
(3, 'bilal', 'bilal@gmail.com', '+9333224338237', 20, 'indoor'),
(4, 'saqib', 'sqi@gmail.com', '+93778778767', 28, 'indoor'),
(5, 'patient2', 'par@gmail.com', '+9333224338237', 34, 'indoor'),
(6, 'junaid', 'junaid@gmail.ckm', '823748939', 47, 'outdoor');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE `wards` (
  `w_id` int(10) NOT NULL,
  `w_date` date NOT NULL DEFAULT current_timestamp(),
  `p_id` int(10) NOT NULL,
  `d_id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`w_id`, `w_date`, `p_id`, `d_id`, `type`) VALUES
(1, '2020-04-21', 1, 2, 'emergency'),
(5, '2020-04-21', 4, 1, 'emergency'),
(6, '2020-04-21', 3, 2, 'ICU'),
(8, '2020-04-21', 1, 1, 'emergency'),
(9, '2020-04-21', 1, 1, 'emergency'),
(10, '2020-04-16', 5, 7, 'ICU'),
(11, '2020-04-17', 4, 5, 'emergency'),
(12, '2019-09-18', 3, 8, 'ICU'),
(13, '2020-04-08', 6, 8, 'emergency');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`ap_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `nurses`
--
ALTER TABLE `nurses`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `wards`
--
ALTER TABLE `wards`
  ADD PRIMARY KEY (`w_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `ap_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `d_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `nurses`
--
ALTER TABLE `nurses`
  MODIFY `n_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `p_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wards`
--
ALTER TABLE `wards`
  MODIFY `w_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
