<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['ap_patient_name'];
	$contact= $_POST['ap_patient_contact'];
	$doctor= $_POST['doctor_name'];
	$day= $_POST['day'];


$sql = "INSERT INTO appointment (ap_patient_name, ap_patient_contact, doctor_name,day)
VALUES ('$name', '$contact', '$doctor', '$day')";

if (mysqli_query($conn, $sql)) {
    header("location:insert.html?insert=4");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}


?>