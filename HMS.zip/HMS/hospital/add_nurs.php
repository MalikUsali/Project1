<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['n_name'];
	$email= $_POST['email'];
	$contact= $_POST['contact'];
	$age= $_POST['age'];
	$shift= $_POST['shift'];


$sql = "INSERT INTO nurses (n_name, email, contact,age,shift)
VALUES ('$name', '$email', '$contact', '$age','$shift')";

if (mysqli_query($conn, $sql)) {
    header("location:insert.html?insert=4");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}


?>