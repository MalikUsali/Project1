<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['p_name'];
	$email= $_POST['email'];
	$contact= $_POST['contact'];
	$age= $_POST['age'];
	$status= $_POST['status'];
	

$sql = "INSERT INTO patient (p_name, email, contact,age,status)
VALUES ('$name', '$email', '$contact', '$age','$status')";

if (mysqli_query($conn, $sql)) {
    header("location:insert.html?insert=4");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}


?>