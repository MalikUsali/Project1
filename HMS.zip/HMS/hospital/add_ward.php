<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$date= $_POST['w_date'];
	$pat= $_POST['p_id'];
	$doc= $_POST['d_id'];
	$type= $_POST['type'];
	
	

$sql = "INSERT INTO wards (w_date,p_id,d_id,type)
VALUES ('$date','$pat','$doc','$type')";

if (mysqli_query($conn, $sql)) {
    header("location:insert.html?insert=4");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

?>
