<?php
include("connection.php");
$query = "select * from appointment";
$select  = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Appointment's View</title>
	<link rel="stylesheet" type="text/css" href="style.css">

	<style>
		table{
		margin-top: 50px;
		background-color: grey;
		color: white;
		text-align: center;
	 }
		table tr{
			background-color: green;
		}
		table tr td{
			background-color: skyblue;
		}
		table a{
			text-decoration: none;
			color: blue;
		}

	</style>

</head>

<body>

	    <!-- for deletion + alert -->
<?php 
 if ((isset($_GET['delete'])) && (isset($_GET['delete']))==1)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Deleted Successfully.
</div>
<?php
}
?> 
          <!-- for updation + alert -->
<?php 
if ((isset($_GET['update'])) && (isset($_GET['update']))==2)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Updated Successfully.
</div>
<?php }
?> 



<table width="100%" align="center" border="solid" cellspacing="10px" cellpadding="5px" style="margin-bottom: 40px">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Contact</th>
			<th>DOCTOR</th>
			<th>Day</th>
			<th>Action</th>
			<th>Action</th>
		</tr>
<?php		
			if(mysqli_num_rows($select)>0)
			{
				while($row = mysqli_fetch_assoc($select)) {
				 
					?>
					<tr>
						<td><?php echo $row['ap_id']; ?></td>
						<td><?php echo $row['ap_patient_name'] ?></td>
						<td><?php echo $row['ap_patient_contact'] ?></td>
						<td><?php echo $row['doctor_name'] ?></td>
						<td><?php echo $row['day'] ?></td>
						<td><a href="update_appt.php?id=<?php echo $row['ap_id'] ?>">Update</a></td>
						<td><a href="delete_appt.php?id=<?php echo $row['ap_id'] ?>">Delete</a></td>
					</tr>
					<?php

				}
			}

			 ?>
			
	</table>

 <a href="index.html" style="border: solid;
			border-radius: 20px;
			padding: 5px 100px;
			background:  linear-gradient(to top left, #00ff00 0%, #00ffff 100%);
			word-spacing: 4px;
			font-weight: bold;
			font-size: 30px;
			text-decoration: none;margin-left: 500px">Go To HomePage</a>

			
</body>
</html>