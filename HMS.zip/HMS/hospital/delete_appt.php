<?php
include "connection.php";

$id=$_GET['id'];

$sql = "DELETE FROM appointment WHERE ap_id='$id'";

if (mysqli_query($conn, $sql)) {
   header("location:appointment_view.php?delete=1");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}



?>