<?php
include "connection.php";

$id=$_GET['id'];

$sql = "DELETE FROM doctor WHERE d_id='$id'";

if (mysqli_query($conn, $sql)) {
   header("location:doc_view.php?delete=1");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>