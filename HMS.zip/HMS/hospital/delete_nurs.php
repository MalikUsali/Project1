<?php
include "connection.php";

$id=$_GET['id'];

$sql = "DELETE FROM nurses WHERE n_id='$id'";

if (mysqli_query($conn, $sql)) {
   header("location:nurs_view.php?delete=1");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}



?>