<?php
include "connection.php";

$id=$_GET['id'];

$sql = "DELETE FROM wards WHERE w_id='$id'";

if (mysqli_query($conn, $sql)) {
   header("location:view_ward.php?delete=1");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}



?>