<?php
include("connection.php");
$query = "select * from nurses";
$select  = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Nurse's View</title>
	<link rel="stylesheet" type="text/css" href="style.css">

	<style>
		table{
		margin-top: 50px;
		background-color: orange;
		color: white;
	 }
		table tr{
			background-color: red;
		}
		table tr td{
			background-color: black;
		}
		table a{
			text-decoration: none;
			color: blue;
		}

	</style>

</head>

<body>

	    <!-- for deletion + alert -->
<?php 
 if ((isset($_GET['delete'])) && (isset($_GET['delete']))==1)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Deleted Successfully.
</div>
<?php
}
?> 
          <!-- for updation + alert -->
<?php 
if ((isset($_GET['update'])) && (isset($_GET['update']))==2)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Updated Successfully.
</div>
<?php }
?> 



<table width="100%" align="center" border="solid" cellspacing="10px" cellpadding="5px" style="margin-bottom: 40px">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Contact</th>
			<th>Age</th>
			<th>Shift</th>
			<th>Action</th>
			<th>Action</th>
		</tr>
<?php		
			if(mysqli_num_rows($select)>0)
			{
				while($row = mysqli_fetch_assoc($select)) {
				 
					?>
					<tr>
						<td><?php echo $row['n_id']; ?></td>
						<td><?php echo $row['n_name'] ?></td>
						<td><?php echo $row['email'] ?></td>
						<td><?php echo $row['contact'] ?></td>
						<td><?php echo $row['age'] ?></td>
						<td><?php echo $row['shift'] ?></td>
						<td><a href="update_nurs.php?id=<?php echo $row['n_id'] ?>">Update</a></td>
						<td><a href="delete_nurs.php?id=<?php echo $row['n_id'] ?>">Delete</a></td>
					</tr>
					<?php

				}
			}

			 ?>
			
	</table>

 <a href="index.html" style="border: solid;
			border-radius: 20px;
			padding: 5px 100px;
			background:  linear-gradient(to top left, #00ff00 0%, #00ffff 100%);
			word-spacing: 4px;
			font-weight: bold;
			font-size: 30px;
			text-decoration: none;margin-left: 500px">Go To HomePage</a>

			
</body>
</html>