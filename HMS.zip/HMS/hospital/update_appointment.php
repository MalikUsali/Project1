<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['ap_patient_name'];
	$contact= $_POST['ap_patient_contact'];
	$doctor= $_POST['doctor_name'];
	$day= $_POST['day'];
	$id=$_POST['ap_id'];
	

$sql = "UPDATE appointment SET  ap_patient_name='$name', ap_patient_contact='$contact',doctor_name='$doctor',day='$day' WHERE ap_id='$id'";


if (mysqli_query($conn, $sql)) {
    header("location:appointment_view.php?update=2");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

?>