 <?php
  include("connection.php");
  $id= $_GET['id'];
  
$query = "select * from appointment where ap_id='$id'";
$select  = mysqli_query($conn,$query);
if(mysqli_num_rows($select)>0)
      {
       $row = mysqli_fetch_assoc($select);
     }

        ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Appointment's</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

<style>
	body{
		background-color: grey;
	}
	form{
	border: 10px solid red;
	padding: 10px 10px;
	background: white;
	margin: 5px 10%;
}

</style>

</head>
<body>

<form method="POST" action="update_appointment.php">
	<legend>Update Here</legend>

<div class="group">
	<label style="margin-right: 170px;">Patient Name</label>
	<input type="text" name="ap_patient_name" required="" value="<?php echo $row['ap_patient_name'] ?>">
</div>

<div class="group">
	<label>Patient Contact</label>
	<input type="tel" name="ap_patient_contact" required=""  value="<?php echo $row['ap_patient_contact'] ?>">
</div>

<div class="group">
	<label style="margin-right: 175px;">Doctor Name</label>
	<input type="text" name="doctor_name" required="" value="<?php echo $row['doctor_name'] ?>">
</div>

<div class="group">
	<label style="margin-right: 290px;">Day</label>
	<input type="text" name="day" required="" value="<?php echo $row['day'] ?>">
</div>


<input type="text" name="ap_id" value="<?php echo $row['ap_id'] ?>" style="display: none;">


<div class="sub">
	<input type="submit" name="submit">
	<input type="reset" name="reset">
</div>


</form>

</body>
</html>