 <?php
  include("connection.php");
  $id= $_GET['id'];
  
$query = "select * from doctor where d_id='$id'";
$select  = mysqli_query($conn,$query);
if(mysqli_num_rows($select)>0)
      {
       $row = mysqli_fetch_assoc($select);
     }

        ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Doctor's</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

<style>

	body{
		background-color: grey;
	}
	form{
	border: 10px solid red;
	padding: 10px 10px;
	background: white;
	margin: 5px 10%;
}


</style>

</head>
<body>

<form method="POST" action="update_doctor.php">
	<legend>Update Here</legend>

<div class="group">
	<label>Name &emsp;</label>
	<input type="text" name="d_name" required="" value="<?php echo $row['d_name'] ?>">
</div>

<div class="group">
	<label>Email &emsp;</label>
	<input type="email" name="email" required="" value="<?php echo $row['email'] ?>">
</div>

<div class="group">
	<label style="margin-right: 165px;">Contact</label>
	<input type="tel" name="contact" required="" value="<?php echo $row['contact'] ?>" >
</div>

<div class="group">
	<label style="margin-right: 210px;">Age</label>
	<input type="integer" name="age" required="" value="<?php echo $row['age'] ?>">
</div>

<div class="group">
	<label style="margin-right: 200px;">Shift</label>
	<input type="text" name="Shift" required="" placeholder="Day / Night" value="<?php echo $row['shift'] ?>">
</div>

<input type="text" name="d_id" value="<?php echo $row['d_id'] ?>" style="display: none;">

<div class="sub">
	<input type="submit" name="submit">
	<input type="reset" name="reset">
</div>


</form>

</body>
</html>