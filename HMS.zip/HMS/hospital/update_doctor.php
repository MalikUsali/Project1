<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['d_name'];
	$email= $_POST['email'];
	$contact= $_POST['contact'];
	$age= $_POST['age'];
	$shift= $_POST['shift'];
	$id=$_POST['d_id'];
	

$sql = "UPDATE doctor SET  d_name='$name', email='$email', contact='$contact',age='$age',shift='$shift' WHERE d_id='$id'";


if (mysqli_query($conn, $sql)) {
    header("location:doc_view.php?update=2");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

?>