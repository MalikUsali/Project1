<?php
include "connection.php";
if (isset($_POST['submit']))
{
	$name= $_POST['p_name'];
	$email= $_POST['email'];
	$contact= $_POST['contact'];
	$age= $_POST['age'];
	$status= $_POST['status'];
	$id=$_POST['p_id'];
	

$sql = "UPDATE patient SET  p_name='$name', email='$email', contact='$contact',age='$age',status='$status' WHERE p_id='$id'";


if (mysqli_query($conn, $sql)) {
    header("location:patient_view.php?update=2");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

?>