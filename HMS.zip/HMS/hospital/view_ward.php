<?php
include("connection.php");
$query = "select  p.*, d.*,w.* from wards w inner join patient p on p.p_id=w.p_id inner join doctor d on d.d_id=w.d_id";

$select  = mysqli_query($conn,$query);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Ward's View</title>
	<link rel="stylesheet" type="text/css" href="style.css">

	<style>
		table{
		margin-top: 50px;
		background-color: brown;
		color: white;
	 }
		table tr{
			background-color: red;
		}
		table tr td{
			background-color: black;
		}
		table a{
			text-decoration: none;
			color: blue;
		}

	</style>

</head>

<body>

	    <!-- for deletion + alert -->
<?php 
 if ((isset($_GET['delete'])) && (isset($_GET['delete']))==1)
{
	?>
<div class="alert alert-success">
	<strong>Successs!</strong>Record Deleted Successfully.
</div>
<?php
}
?> 



<table width="100%" align="center" border="solid" cellspacing="10px" cellpadding="5px" style="margin-bottom: 40px">
		<tr>
			<th>ID</th>
			<th>Date</th>
			<th>Patient</th>
			<th>Doctor</th>
			<th>Type</th>
			<th>Contact</th>
			<th>Action</th>
			
		</tr>
<?php		
			if(mysqli_num_rows($select)>0)
			{
				while($row = mysqli_fetch_assoc($select)) {
				 
					?>

					<tr>
						<td><?php echo $row['w_id']; ?></td>
						<td><?php echo $row['w_date']; ?></td>
						<td><?php echo $row['p_name'] ?></td>
						<td><?php echo $row['d_name'] ?></td>
						<td><?php echo $row['type'] ?></td>
						<td><?php echo $row['contact'] ?></td>
						<td><a href="delete_ward.php?id=<?php echo $row['w_id'] ?>">Delete</a></td>
					
					</tr>
					<?php

				}
			}

			 ?>
			
	</table>

 <a href="index.html" style="border: solid;
			border-radius: 20px;
			padding: 5px 100px;
			background:  linear-gradient(to top left, #00ff00 0%, #00ffff 100%);
			word-spacing: 4px;
			font-weight: bold;
			font-size: 30px;
			text-decoration: none;margin-left: 500px">Go To HomePage</a>

			
</body>
</html>