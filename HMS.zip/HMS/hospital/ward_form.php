<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Ward's</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">

<style>

	form{
	border: 10px solid red;
	padding: 10px 10px;
	background: brown;
	margin: 5px 10%;
}

</style>

</head>
<body>

<form method="POST" action="add_ward.php">
	<legend>Wards info</legend>
<div class="group">
	<label>Date</label>
	<input type="date" name="w_date" required="" style="margin-left: 70px;">
</div>


<div class="group">
	<label>Patient name</label>
	<select name="p_id" style="padding:7px 116px;margin-left: -27px;">
		<?php
		include("connection.php");
$query = "select p_id, p_name from patient";
$select  = mysqli_query($conn,$query);
if(mysqli_num_rows($select)>0)
      {
        while($row = mysqli_fetch_assoc($select)) { 
		?>

		<option value="<?php echo $row['p_id'] ?>"><?php echo $row['p_name']?></option>
  <?php
}
}
?>
	</select>
</div>

<div class="group">
	<label>Available Doctor's</label>
	<select name="d_id"  style="padding:7px 108px;margin-left: -93px;  ">
		<?php
		include("connection.php");
$query = "select d_id, d_name from doctor";
$select  = mysqli_query($conn,$query);
if(mysqli_num_rows($select)>0)
      {
        while($row = mysqli_fetch_assoc($select)) { 
		?>
		<option value="<?php echo $row['d_id'] ?>"><?php echo $row['d_name']?></option>
  <?php
}
}
?>
	</select>
</div>


<div class="group">
	<label>Ward Type</label>
	<input type="text" name="type" required="" placeholder="Emergency / etc">
</div>

<div class="sub">
	<input type="submit" name="submit">
	<input type="reset" name="reset">
</div>

</form>

</body>
</html>